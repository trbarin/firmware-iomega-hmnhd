﻿English:

Iomega strongly recommends all customers install the update file. This update will change some of the default behaviors on your device.

NOTE: All customers who have Remote Access enabled should apply this update.

This version includes these changes:
 • Updates default permissions on USB shares to admin only
 • FTP is no longer a supported protocol for USB shares
 • Adds robots.txt to default shares on the device
 • Fixes an issue with Remote Access and secure SSL certificates



Français :

Iomega recommande vivement à tous ses clients d'installer le fichier de mise à jour. Cette mise à jour modifiera certains des comportements par défaut de votre périphérique.

REMARQUE : tous les clients utilisant la fonctionnalité d'accès à distance devraient installer cette mise à jour.

Cette version comporte les modifications suivantes :
 • Mise à jour des autorisations par défaut des partages USB afin qu'elles soient uniquement attribuées à l'administrateur
 • Le protocole FTP n'est plus pris en charge pour les partages USB
 • Ajout du fichier robots.txt aux partages par défaut du périphérique
 • Résolution d'un problème rencontré avec la fonctionnalité d'accès à distance et les certificats SSL sécurisés



Deutsch:

Iomega empfiehlt dringend allen Kunden, die Aktualisierungsdatei zu installieren. Durch dieses Update werden einige der Standardeinstellungen Ihres Geräts geändert.

HINWEIS: Kunden mit aktiviertem Remote Access sollten dieses Update durchführen.

Diese Version beinhaltet die folgenden Änderungen:
 • Aktualisiert Standardberechtigungen für USB-Freigaben auf "Nur Administrator"
 • FTP-Protokoll wird für USB-Freigaben nicht länger unterstützt
 • Fügt robots.txt zu den Standardfreigaben auf dem Gerät hinzu
 • Behebt einen Fehler mit Remote Access und sicheren SSL-Zertifikaten



Italiano:

Iomega consiglia ai propri clienti di installare il file di aggiornamento. L'aggiornamento apporterà alcune modifiche alle impostazioni predefinite del dispositivo.

NOTA: si consiglia a tutti i clienti che hanno Accesso Remoto abilitato di installare l'aggiornamento.

Questa versione include le seguenti modifiche:
 • Aggiornamento delle autorizzazioni predefinite sulle condivisioni USB riservato all’amministratore
 • Il protocollo FTP non è più supportato per le condivisioni USB
 • Aggiunta di robots.txt alle condivisioni predefinite sul dispositivo
 • Correzione di un problema relativo ad Accesso Remoto e alle certificazioni SSL sicure



Español:

Iomega recomienda encarecidamente que todos los clientes instalen el archivo de actualización. Esta actualización cambia algunos de los comportamientos predeterminados de su dispositivo.

NOTA: Todos los clientes que tengan la función Acceso remoto activada deben aplicar esta actualización.

Esta versión incluye los siguientes cambios:
 • Actualiza los permisos predeterminados sobre los recursos compartidos USB al administrador únicamente
 • Ya no se admite el protocolo FTP para recursos compartidos USB
 • Añade robots.txt a los recursos compartidos predeterminados del dispositivo
 • Soluciona un problema con el acceso remoto y los certificados SSL seguros



Português:

A Iomega recomenda que todos os clientes instalem o arquivo de atualização. Esta atualização vai alterar alguns comportamentos padrão do seu dispositivo.

OBSERVAÇÃO: todos os clientes que têm o Acesso Remoto habilitado devem aplicar essa atualização.

Esta versão inclui estas alterações:
 • Atualiza as permissões padrão nos compartilhamentos USB apenas para o administrador
 • O FTP não é mais um protocolo suportado para compartilhamentos USB
 • Acrescenta o arquivo robots.txt aos compartilhamentos padrão no dispositivo
 • Corrige um problema com o Acesso Remoto e os certificados SSL seguros



Svenska:

Iomega rekommenderar starkt alla kunder att installera uppdateringsfilen. Den här uppdateringen ändrar vissa av standardbeteendena hos enheten.

OBS! Alla kunder som har fjärråtkomst aktiverat ska verkställa den här uppdateringen.

Den här versionen inkluderar följande ändringar:
 • Uppdaterar endast standardbehörigheterna på USB-delningar för admin
 • FTP är inte längre ett protokoll som stöds för USB-delningar
 • Lägger till robots.txt till standarddelningar på enheten
 • Korrigerar ett fel med fjärråtkomst och säkra SSL-certifikat



Polski:

Firma Iomega zdecydowanie zaleca wszystkim klientom zainstalowanie zaktualizowanego pliku. Aktualizacja zmienia niektóre zachowania domyślne urządzenia.

UWAGA: Aktualizację powinni zainstalować wszyscy klienci korzystający z dostępu zdalnego.

Zmiany w tej wersji:
 • Aktualizacja uprawnień domyślnych udziałów USB tylko dla administratora.
 • Udziały USB nie obsługują już protokołu FTP.
 • Plik robots.txt jest dodawany do udziałów domyślnych urządzenia.
 • Usunięty problem z dostępem zdalnym i bezpiecznymi certyfikatami SSL.



Русский:

Компания Iomega настоятельно рекомендует всем клиентам установить файл обновления. Это обновление может привести к некоторым изменениям в поведении устройства по умолчанию.

ПРИМЕЧАНИЕ. Всем пользователям, использующим функцию удаленного доступа, необходимо применить это обновление.

Эта версия содержит следующие изменения:
 • По умолчанию доступ к общим папкам на USB-устройствах теперь разрешен только пользователям с правами администратора
 • FTP больше не является поддерживаемым протоколом для общих папок на USB
 • Файл robots.txt добавлен в список общих папок по умолчанию на устройстве
 • Устранена проблема удаленного доступа и использования безопасных SSL-сертификатов



עברית:

Iomega ממליצה בחום שכל הלקוחות יתקינו את קובץ העדכון. עדכון זה ישנה חלק מהתנהגויות ברירת המחדל בהתקן.

הערה: חשוב שכל הלקוחות שמופעלת אצלם האפשרות Remote Access (גישה מרחוק), יתקינו את העדכון.

גרסה זו כוללת את השינויים הבאים:
 • עדכון הרשאות ברירת המחדל בשיתופי USB למפעילים בלבד (admin only‏)
 • כבר אין תמיכה בפרוטוקול FTP בשיתופי USB
 • הוספה של robots.txt לשיתופי ברירת המחדל על ההתקן
 • תיקון בעיה ב-Remote Access (גישה מרחוק) ובאישורי SSL מאובטחים



Türk:

Iomega tüm müşterilerin güncelleme dosyasını kurmasını şiddetle tavsiye eder. Bu güncelleme cihazınızdaki bazı varsayılan davranışları değiştirecektir.

DİKKAT: Uzaktan Erişim’i etkin olan tüm müşteriler bu güncellemeyi uygulamalıdır.

Bu sürüm aşağıdaki değişiklikleri içermektedir:
 • USB paylaşımlar üzerindeki varsayılan izinleri sadece yönetici olarak günceller
 • USB paylaşımlar için FTP artık desteklenmez
 • Cihaz üzerindeki varsayılan paylaşımlara robots.txt eklenir
 • Uzaktan Erişim ve güvenli SSL sertifikaları ile ilgili bir sorunu giderir



العربية:

تنصح شركة Iomega بشدة كافة العملاء بتثبيت ملف التحديث. سيقوم هذا التحديث بتغيير بعض السلوكيات الافتراضية للجهاز الخاص بك.

ملاحظة: ينبغي على كافة العملاء المُمكَّن لديهم "الوصول عن بعد" تطبيق هذا التحديث.

يتضمن هذا الإصدار التغييرات التالية:
 • تحديث الأذونات الافتراضية على المشاركات عبر USB للمسئول فقط
 • لم يعد FTP بروتوكولاً مدعومًا للمشاركات عبر USB
 • إضافة robot.txt إلى المشاركات الافتراضية على الجهاز
 • إصلاح إحدى المشكلات في "الوصول عن بعد" وتأمين شهادات SSL



简体中文：

Iomega 强烈建议所有用户安装此更新文件。此更新将更改您设备上的一些默认行为。

注：所有启用了“远程访问”的用户应当应用此更新。

此版本包含以下更改：
• 将 USB 共享的默认权限更新为仅限管理员具有该权限
• FTP 不再是 USB 共享支持的协议
• 将 robots.txt 添加到设备的默认共享
• 修复远程访问和安全 SSL 认证的问题



繁體中文：

Iomega 強烈建議所有客戶安裝更新檔案。此更新將變更您裝置中的某些預設行為。

附註：所有啟用「遠端存取」的客戶應套用此更新。

此版本包括的變更如下：
• 將 USB 共用的預設權限更新為僅限管理員
• FTP 不再為支援 USB 共用的通訊協定。
• 將 robots.txt 新增至裝置中的預設共用
• 修正「遠端存取」和安全 SSL 憑證



日本語:

Iomega では、すべてのお客様がアップデート ファイルをインストールすることを強くお勧めします。このアップデートにより、デバイスのデフォルトの動作が一部変更されます。

注記: リモート アクセスを有効にしているお客様は必ずこのアップデートを実行してください。

このバージョンに含まれている変更点は以下のとおりです。
• USB 共有フォルダのデフォルトの権限を admin のみに限定しました
• USB 共有フォルダで FTP がプロトコルとしてサポートされなくなりました
• デバイスのデフォルトの共有フォルダに robots.txt を追加しました
• リモート アクセスとセキュア SSL 証明書の問題を解決しました



한국:

Iomega에서는 모든 고객이 업데이트 파일을 설치하는 것을 권장합니다. 업데이트 파일을 설치하면 디바이스의 일부 기본 동작이 변경됩니다.

참고: 원격 액세스 기능을 사용하는 모든 고객은 이 업데이트를 적용해야 합니다.

이 버전의 변경 사항은 다음과 같습니다.
 • 관리자 전용 USB 공유에 대한 기본 권한을 업데이트합니다.
 • FTP가 더 이상 USB 공유 프로토콜로 지원되지 않습니다.
 • 디바이스의 기본 공유에 robots.txt를 추가합니다.
 • 원격 액세스 및 보안 SSL 인증서와 관련된 문제를 해결합니다.


